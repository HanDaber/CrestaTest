Win32-GuiTest Recorder v1.03 (05-29-2004)
----------------------------------------------
An initial script recording application to use with
Win32::GuiTest (1.50.x-ad and greater).

Updates, source, and general information regarding this
product are currently available at:
http://sourceforge.net/projects/winguitest

Also, you should read the application's About Box;
which can be found in its system menu.

You may distribute under the terms of the GNU General 
Public License.  Please refer to Copying.txt for more
information.

----------------------------------------------
